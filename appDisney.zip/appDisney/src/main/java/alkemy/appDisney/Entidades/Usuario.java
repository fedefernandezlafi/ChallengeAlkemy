/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package alkemy.appDisney.Entidades;

//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.Id;
//import org.hibernate.annotations.GenericGenerator;

/**
 * 
 * @author Federico Fernandez Lafi <ffernandezlafi at gmail.com>
 */
//@Entity
//public class Usuario {
//    @Id
//    @GeneratedValue (generator = "uuid")
//    @GenericGenerator (name = "uuid", strategy = "uuid2")
//    private String id;
//    private String nombre;
//    private String apellido;
//    private String clave1;
//    private String clave2;
//    private String mail;
//
//    public String getId() {
//        return id;
//    }
//
//    public void setId(String id) {
//        this.id = id;
//    }
//
//    public String getNombre() {
//        return nombre;
//    }
//
//    public void setNombre(String nombre) {
//        this.nombre = nombre;
//    }
//
//    public String getApellido() {
//        return apellido;
//    }
//
//    public void setApellido(String apellido) {
//        this.apellido = apellido;
//    }
//
//    public String getClave1() {
//        return clave1;
//    }
//
//    public void setClave1(String clave1) {
//        this.clave1 = clave1;
//    }
//
//    public String getClave2() {
//        return clave2;
//    }
//
//    public void setClave2(String clave2) {
//        this.clave2 = clave2;
//    }
//
//    public String getMail() {
//        return mail;
//    }
//
//    public void setMail(String mail) {
//        this.mail = mail;
//    }
    
    

           
          
//}
