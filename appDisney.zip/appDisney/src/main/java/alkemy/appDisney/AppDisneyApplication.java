package alkemy.appDisney;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppDisneyApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppDisneyApplication.class, args);
	}

}
