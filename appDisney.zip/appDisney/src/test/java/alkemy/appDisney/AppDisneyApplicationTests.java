package alkemy.appDisney;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppDisneyApplicationTests {

	@Test
	void contextLoads() {
	}

}
